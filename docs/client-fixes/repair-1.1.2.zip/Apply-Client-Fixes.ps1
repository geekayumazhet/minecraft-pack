$ErrorActionPreference = 'Stop'
$root = [IO.Path]::GetFullPath($PSScriptRoot)
$targets = @()
foreach ($relative in @('instance','PineconeMC\instances')) {
    $container = Join-Path $root $relative
    if (Test-Path -LiteralPath $container -PathType Container) {
        foreach ($dir in @(Get-ChildItem -LiteralPath $container -Directory)) {
            if ($dir.Name -match 'backup|^install-' -or -not (Test-Path -LiteralPath (Join-Path $dir.FullName 'mmc-pack.json'))) { continue }
            $metadata = Get-Content -LiteralPath (Join-Path $dir.FullName 'mmc-pack.json') -Raw -Encoding UTF8 | ConvertFrom-Json
            if (@($metadata.components | Where-Object { $_.uid -eq 'net.neoforged' -and $_.version -eq '21.1.256' }).Count -eq 1) { $targets += $dir.FullName }
        }
    }
}
if (-not $targets.Count) { throw 'Extract this patch INSIDE the existing Minecraft-Pack folder, then run APPLY-CLIENT-FIXES.bat.' }
Write-Host 'This patch restores client controls, hidden armor, the previous shader and Russian UI text.'
Write-Host 'It also enables the compatible NeoForge 256 update channel. Personal files are backed up.'
Write-Host 'Close Minecraft on this computer. Do not stop the game server.'
if ((Read-Host 'Type YES to confirm that Minecraft is closed and apply the patch') -cne 'YES') { exit 1 }
foreach ($target in $targets) {
    & powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $root 'Repair-Client.ps1') -Instance $target -PayloadDirectory (Join-Path $root 'client-fixes') -EnableAuto -GameClosedConfirmed
    if ($LASTEXITCODE -ne 0) { throw 'Repair stopped. Keep the existing pack and the printed error; do not delete your instance.' }
}
Write-Host 'Client settings repaired. Compatible updates will be checked before the next launch.'
