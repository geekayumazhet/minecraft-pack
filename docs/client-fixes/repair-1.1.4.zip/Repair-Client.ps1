param(
    [Parameter(Mandatory=$true)][string]$Instance,
    [string]$PayloadDirectory = (Join-Path $PSScriptRoot 'client-fixes'),
    [switch]$EnableAuto,
    [switch]$GameClosedConfirmed,
    [switch]$DryRun
)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
$utf8 = [Text.UTF8Encoding]::new($false)
$game = Join-Path ([IO.Path]::GetFullPath($Instance)) 'minecraft'
$control = Join-Path $game '.pack-update'
$locks = @()
$promoted = @()
$writes = [ordered]@{}
$before = @{}
function Assert-Regular([string]$Path) {
    $cursor = [IO.Path]::GetFullPath($Path)
    while ($cursor) {
        if ((Test-Path -LiteralPath $cursor) -and ((Get-Item -LiteralPath $cursor -Force).Attributes -band [IO.FileAttributes]::ReparsePoint)) { throw 'Links are not supported for client repair.' }
        $cursor = [IO.Path]::GetDirectoryName($cursor)
    }
}
function Hash-Bytes([byte[]]$Bytes) {
    $sha = [Security.Cryptography.SHA256]::Create()
    try { return [BitConverter]::ToString($sha.ComputeHash($Bytes)).Replace('-','').ToLowerInvariant() }
    finally { $sha.Dispose() }
}
function Read-Object([string]$Path) { return ([IO.File]::ReadAllText($Path, $utf8) | ConvertFrom-Json) }
function Text([string]$Relative) {
    $p = Join-Path $game $Relative
    if (Test-Path -LiteralPath $p) { return [IO.File]::ReadAllText($p, $utf8) }
    return ''
}
function Merge-Line([string]$Text, [string]$Key, [string]$Value, [string]$Separator) {
    $pattern = '(?m)^' + [Regex]::Escape($Key + $Separator) + '[^\r\n]*'
    $matches = [Regex]::Matches($Text, $pattern)
    if ($matches.Count -gt 1) { throw ('Duplicate setting: ' + $Key) }
    $replacement = $Key + $Separator + $Value
    if ($matches.Count) { return [Regex]::Replace($Text, $pattern, [Text.RegularExpressions.MatchEvaluator]{ param($m) $replacement }) }
    if ($Text -and -not $Text.EndsWith("`n")) { $Text += "`n" }
    return $Text + $replacement + "`n"
}
function Schedule-Text([string]$Relative, [string]$Value) { $writes[$Relative] = $utf8.GetBytes($Value) }
function Assert-GameClosed {
    $serverPids = @(Get-NetTCPConnection -LocalPort 25565 -State Listen -ErrorAction SilentlyContinue | ForEach-Object { $_.OwningProcess })
    foreach ($p in @(Get-CimInstance Win32_Process -Filter "Name='java.exe' OR Name='javaw.exe'")) {
        if (-not $p.CommandLine) {
            if ($p.ProcessId -notin $serverPids -and -not $GameClosedConfirmed) { throw 'An unidentified Java process is running. Explicitly confirm that Minecraft is closed before repair.' }
        } elseif ($p.CommandLine.Replace('/','\').IndexOf($game.Replace('/','\'), [StringComparison]::OrdinalIgnoreCase) -ge 0) { throw 'Minecraft is running in this instance. Close it before repair.' }
    }
}
function Atomic-Write([string]$Path, [byte[]]$Bytes) {
    Assert-Regular $Path
    [IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($Path)) | Out-Null
    $tmp = $Path + '.' + [Guid]::NewGuid().ToString('N') + '.new'
    [IO.File]::WriteAllBytes($tmp, $Bytes)
    if (Test-Path -LiteralPath $Path) { [IO.File]::Replace($tmp, $Path, (Join-Path $control ('atomic-previous-' + [Guid]::NewGuid().ToString('N')))) }
    else { [IO.File]::Move($tmp, $Path) }
}
try {
    Assert-Regular $game
    Assert-Regular $PayloadDirectory
    $metadata = Read-Object (Join-Path $Instance 'mmc-pack.json')
    if (@($metadata.components | Where-Object { $_.uid -eq 'net.minecraft' -and $_.version -eq '1.21.1' }).Count -ne 1 -or
        @($metadata.components | Where-Object { $_.uid -eq 'net.neoforged' -and $_.version -eq '21.1.256' }).Count -ne 1) { throw 'This repair is for Minecraft 1.21.1 / NeoForge 21.1.256 only.' }
    $plan = Read-Object (Join-Path $PayloadDirectory 'plan.json')
    if ($plan.format -ne 1 -or $plan.id -cne 'client-settings-20261025-v1') { throw 'Unsupported repair plan.' }
    Assert-GameClosed
    [IO.Directory]::CreateDirectory($control) | Out-Null
    foreach ($name in @('bootstrap.lock', 'update.lock')) { $locks += [IO.File]::Open((Join-Path $control $name), 'OpenOrCreate', 'ReadWrite', 'None') }
    $marker = Join-Path $control 'client-settings-applied.json'
    $already = (Test-Path -LiteralPath $marker) -and (Read-Object $marker).id -ceq $plan.id
    if (-not $already) {
        $options = Text 'options.txt'
        foreach ($binding in $plan.keys.PSObject.Properties) {
            if ($binding.Name -notmatch '^key_[A-Za-z0-9_.]+$' -or $binding.Value -notmatch '^key\.keyboard\.[a-z0-9.]+$') { throw 'Invalid reviewed key binding.' }
            $options = Merge-Line $options $binding.Name $binding.Value ':'
        }
        $packsMatch = [Regex]::Match($options, '(?m)^resourcePacks:([^\r\n]*)')
        $packs = @('vanilla')
        if ($packsMatch.Success) {
            if (-not $packsMatch.Groups[1].Value.Trim().StartsWith('[')) { throw 'Resource-pack preferences must be a JSON array.' }
            $parsedPacks = $packsMatch.Groups[1].Value | ConvertFrom-Json
            $packs = @()
            if ($null -ne $parsedPacks) { $packs = @($parsedPacks) }
        }
        if (@($packs | Where-Object { $_ -isnot [string] }).Count) { throw 'Invalid resource-pack preferences.' }
        $newPack = 'file/chronicle_client_fixes_ru_v1.zip'
        $packs = @($packs | Where-Object { $_ -cne $newPack }) + @($newPack)
        $options = Merge-Line $options 'resourcePacks' (ConvertTo-Json -InputObject $packs -Compress) ':'
        $options = Merge-Line $options 'lang' 'ru_ru' ':'
        Schedule-Text 'options.txt' $options
        $armorText = Text 'config/armor-hider.json'
        $armor = if ($armorText) { $armorText | ConvertFrom-Json } else { [pscustomobject]@{} }
        foreach ($setting in $plan.armor.PSObject.Properties) {
            if ($setting.Name -notin @('helmetOpacity','chestOpacity','legsOpacity','bootsOpacity','disableArmorHider','disableArmorHiderForOthers','usePlayerSettingsWhenUndeterminable')) { throw 'Unexpected armor-setting field.' }
            $armor | Add-Member -NotePropertyName $setting.Name -NotePropertyValue $setting.Value -Force
        }
        Schedule-Text 'config/armor-hider.json' ($armor | ConvertTo-Json -Depth 8)
        $iris = Merge-Line (Text 'config/iris.properties') 'shaderPack' 'ComplementaryReimagined_r5.9.3.zip' '='
        Schedule-Text 'config/iris.properties' (Merge-Line $iris 'enableShaders' 'true' '=')
        foreach ($asset in @(
            @('chronicle_client_fixes_ru_v1.zip','resourcepacks/chronicle_client_fixes_ru_v1.zip',$plan.resourcePackSha256),
            @('ComplementaryReimagined_r5.9.3.zip','shaderpacks/ComplementaryReimagined_r5.9.3.zip',$plan.shaderSha256))) {
            $payload = Join-Path $PayloadDirectory $asset[0]
            Assert-Regular $payload
            $bytes = [IO.File]::ReadAllBytes($payload)
            if ((Hash-Bytes $bytes) -cne $asset[2]) { throw ('Repair asset is corrupt: ' + $asset[0]) }
            $target = Join-Path $game $asset[1]
            if ((Test-Path -LiteralPath $target) -and (Hash-Bytes ([IO.File]::ReadAllBytes($target))) -cne $asset[2]) { throw ('A personal file conflicts with the repair asset: ' + $asset[1]) }
            $writes[$asset[1]] = $bytes
        }
        Schedule-Text '.pack-update/client-settings-applied.json' (@{ id=$plan.id; appliedAt=[DateTime]::UtcNow.ToString('o') } | ConvertTo-Json)
    }
    if ($EnableAuto) {
        # Verify the prepared publication before leaving PINNED protection.
        $releaseVersion = if ($plan.PSObject.Properties.Name -contains 'releaseVersion') { $plan.releaseVersion } else { '1.1.2' }
        if ($releaseVersion -isnot [string] -or $releaseVersion -cnotmatch '^[0-9]{1,6}\.[0-9]{1,6}\.[0-9]{1,6}$') { throw 'Invalid repair release version.' }
        if ($plan.catalogSha256 -cnotmatch '^[a-f0-9]{64}$' -or $plan.engineSha256 -cnotmatch '^[a-f0-9]{64}$') { throw 'A verified compatible publication is required before AUTO can be enabled.' }
        [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
        $url = 'https://geekayumazhet.github.io/minecraft-pack/stable-neoforge256/pack-release.json'
        $response = Invoke-WebRequest -UseBasicParsing -Uri $url -TimeoutSec 20
        $remoteBytes = $utf8.GetBytes($response.Content)
        if ((Hash-Bytes $remoteBytes) -cne $plan.catalogSha256) { throw 'The compatible update channel is not published yet. PINNED mode preserved.' }
        $remote = $response.Content | ConvertFrom-Json
        if ($remote.version -cne $releaseVersion -or $remote.platform.neoforge -cne '21.1.256') { throw 'Unexpected update-channel platform.' }
        $engineUrl = 'https://geekayumazhet.github.io/minecraft-pack/updater-neoforge256/manifest.json'
        $engine = (Invoke-WebRequest -UseBasicParsing -Uri $engineUrl -TimeoutSec 20).Content | ConvertFrom-Json
        if ($engine.sha256 -cne $plan.engineSha256) { throw 'The compatible updater engine is not published yet.' }
        $settings = Read-Object (Join-Path $game 'pack-update-tools/settings.json')
        $settings.mode = 'AUTO'; $settings.packUrl = 'https://geekayumazhet.github.io/minecraft-pack/stable-neoforge256/pack.toml'
        Schedule-Text 'pack-update-tools/settings.json' ($settings | ConvertTo-Json)
    }
    foreach ($relative in @($writes.Keys)) {
        $path = Join-Path $game $relative
        Assert-Regular $path
        $old = if (Test-Path -LiteralPath $path) { [IO.File]::ReadAllBytes($path) } else { $null }
        $before[$relative] = $old
        if ($null -ne $old -and (Hash-Bytes $old) -ceq (Hash-Bytes $writes[$relative])) { $writes.Remove($relative) }
    }
    if ($DryRun) { Write-Host ('[Client repair] Dry run: ' + $writes.Count + ' targeted files would change.'); exit 0 }
    Assert-GameClosed
    if ($writes.Count) {
        $backup = Join-Path $control ('settings-backup-' + [DateTime]::UtcNow.ToString('yyyyMMddTHHmmss') + '-' + [Guid]::NewGuid().ToString('N'))
        foreach ($relative in $writes.Keys) {
            if ($null -ne $before[$relative]) { Atomic-Write (Join-Path $backup $relative) $before[$relative] }
        }
        foreach ($relative in $writes.Keys) {
            $path = Join-Path $game $relative
            $actual = if (Test-Path -LiteralPath $path) { Hash-Bytes ([IO.File]::ReadAllBytes($path)) } else { $null }
            $expected = if ($null -ne $before[$relative]) { Hash-Bytes $before[$relative] } else { $null }
            if ($actual -cne $expected) { throw 'A setting changed during repair. No further files will be promoted.' }
            Atomic-Write $path $writes[$relative]; $promoted += $relative
        }
    }
    Write-Host ('[Client repair] Complete. Changed ' + $writes.Count + ' files; personal settings and any original identity fields retained.')
} catch {
    foreach ($relative in @($promoted | Sort-Object -Descending)) {
        $path = Join-Path $game $relative
        if ($null -ne $before[$relative]) { Atomic-Write $path $before[$relative] }
        else { Assert-Regular $path; Remove-Item -LiteralPath $path }
    }
    Write-Error $_
    exit 1
} finally {
    foreach ($lock in $locks) { $lock.Dispose() }
}
